package com.example.consumoapi.model

class ExercisesResult : ArrayList<ExercisesResultItem>()